import os
import io
import zipfile
import tempfile
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

import sys
BASE_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE_DIR / 'ai_novel_writer'))

from config.settings import settings
from ai.providers import get_provider
from ai.novel_generator import NovelGenerator, Chapter


app = FastAPI(title="AI Novel Mobile Backend", version="0.1.0")


class ContinueParams(BaseModel):
    start_chapter: int
    chapter_words: int = 3000
    chapter_count: int = 1
    until_finale: bool = False
    # generation params
    temperature: float = settings.config.get('generation', {}).get('temperature', 0.8)
    max_tokens: int = settings.config.get('generation', {}).get('max_tokens', 4096)
    frequency_penalty: float = settings.config.get('generation', {}).get('frequency_penalty', 0.3)
    presence_penalty: float = settings.config.get('generation', {}).get('presence_penalty', 0.0)


def _project_dir(project_id: str) -> Path:
    save_config = settings.config.get('save', {})
    base_path = Path(save_config.get('save_path', Path.home() / 'Documents' / 'AI小说'))
    return base_path / project_id


def _natural_sort_key(name: str):
    import re
    nums = re.findall(r"\d+", name)
    return (int(nums[0]) if nums else 1_000_000_000, name)


def _read_text_file(path: Path) -> Optional[str]:
    try:
        return path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        try:
            return path.read_text(encoding='gbk')
        except Exception:
            return None


@app.get("/projects")
def list_projects():
    save_config = settings.config.get('save', {})
    base_path = Path(save_config.get('save_path', Path.home() / 'Documents' / 'AI小说'))
    base_path.mkdir(parents=True, exist_ok=True)
    items = []
    for p in sorted(base_path.iterdir() if base_path.exists() else [], key=lambda x: x.name):
        if p.is_dir():
            items.append({"id": p.name})
    return {"projects": items}


@app.get("/projects/{project_id}/chapters")
def list_chapters(project_id: str):
    proj = _project_dir(project_id)
    if not proj.exists():
        return {"chapters": []}
    chapters = []
    for txt in sorted(proj.glob("*.txt"), key=lambda x: _natural_sort_key(x.name)):
        if "（完整版）" in txt.name:
            continue
        chapters.append({"file": txt.name})
    return {"chapters": chapters}


@app.post("/projects/{project_id}/import")
async def import_project(project_id: str, file: UploadFile = File(...)):
    proj = _project_dir(project_id)
    proj.mkdir(parents=True, exist_ok=True)

    filename = file.filename or "upload"
    content = await file.read()

    # Single TXT
    if filename.lower().endswith('.txt'):
        target = proj / filename
        with open(target, 'wb') as f:
            f.write(content)
        return {"ok": True, "type": "txt", "saved": target.name}

    # Folder zip
    if filename.lower().endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            extracted = []
            for name in zf.namelist():
                if name.endswith('/'):
                    continue
                if not name.lower().endswith('.txt'):
                    continue
                data = zf.read(name)
                base = os.path.basename(name)
                out = proj / base
                with open(out, 'wb') as f:
                    f.write(data)
                extracted.append(base)
        extracted.sort(key=_natural_sort_key)
        return {"ok": True, "type": "zip", "count": len(extracted), "files": extracted[:10]}

    raise HTTPException(status_code=400, detail="Only .txt or .zip supported")


@app.post("/projects/{project_id}/clear")
def clear_project(project_id: str, delete_disk: bool = Form(False)):
    proj = _project_dir(project_id)
    if delete_disk and proj.exists():
        import shutil
        shutil.rmtree(proj)
        return {"ok": True, "deleted": True}
    # else just clear memory (no-op here)
    return {"ok": True, "deleted": False}


def _load_provider():
    provider_config = settings.get_current_provider_config()
    if not provider_config or not provider_config.get('enabled'):
        raise HTTPException(status_code=400, detail="AI provider not configured/enabled")
    provider_name = settings.config.get('current_provider', 'openai')
    return get_provider(
        provider_name,
        provider_config.get('api_key', ''),
        provider_config.get('api_base', ''),
        provider_config.get('model', '')
    )


def _load_existing_chapters(project_id: str) -> List[Chapter]:
    proj = _project_dir(project_id)
    chapters: List[Chapter] = []
    if not proj.exists():
        return chapters
    files = sorted([p for p in proj.glob('*.txt') if '（完整版）' not in p.name], key=lambda x: _natural_sort_key(x.name))
    num = 1
    for p in files:
        text = _read_text_file(p)
        if not text:
            continue
        title = p.stem
        chapters.append(Chapter(
            number=num,
            title=title,
            content=text,
            outline="",
            word_count=len(text),
            status='completed',
            created_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        num += 1
    return chapters


@app.post("/projects/{project_id}/continue")
def continue_project(project_id: str, params: ContinueParams):
    provider = _load_provider()
    generator = NovelGenerator(provider)
    generator.chapters = _load_existing_chapters(project_id)

    proj = _project_dir(project_id)
    proj.mkdir(parents=True, exist_ok=True)

    def is_finale(text: str, title: str = "") -> bool:
        candidates = [title, text[:200], text[-200:]]
        keywords = ["终章", "大结局", "全书完", "完结", "THE END"]
        for c in candidates:
            if not c:
                continue
            for kw in keywords:
                if kw in c:
                    return True
        return False

    def stream():
        generated = 0
        max_auto = 200
        start = params.start_chapter
        while True:
            if not params.until_finale and generated >= params.chapter_count:
                break
            if params.until_finale and generated >= max_auto:
                break

            chapter_num = start + generated
            yield f"data: 开始生成第{chapter_num}章\n\n"

            # chapter outline
            outline = generator.generate_chapter_outline(chapter_num, generator.chapters[-3:])
            title = generator.generate_chapter_title(chapter_num, outline)
            # streaming content (concatenate)
            content_parts: List[str] = []
            for chunk in generator.generate_chapter_content(
                chapter_num=chapter_num,
                chapter_outline=outline,
                target_words=params.chapter_words,
                previous_chapters=generator.chapters,
                mode='auto',
                temperature=params.temperature,
                max_tokens=params.max_tokens,
                frequency_penalty=params.frequency_penalty,
                presence_penalty=params.presence_penalty,
                callback=lambda t: None,
            ):
                content_parts.append(chunk)
                yield f"data: {chunk}\n\n"
            content = ''.join(content_parts)

            # append chapter
            chapter = Chapter(
                number=chapter_num,
                title=title,
                content=content,
                outline=outline,
                word_count=len(content),
                status='completed',
                created_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            )
            generator.chapters.append(chapter)

            # save chapter file
            chapter_filename = f"第{chapter_num:03d}章 {title}.txt"
            safe_name = ''.join(c for c in chapter_filename if c not in '<>:"/\\|?*').strip() or f"第{chapter_num:03d}章"
            with open(proj / safe_name, 'w', encoding='utf-8') as f:
                f.write(f"# 第{chapter.number}章：{chapter.title}\n\n")
                f.write(chapter.content)
                f.write(f"\n\n---\n字数：{chapter.word_count}\n生成时间：{chapter.created_at}")

            # update full file
            full_name = f"{project_id}（完整版）.txt"
            with open(proj / full_name, 'w', encoding='utf-8') as f:
                f.write(f"《{project_id}》\n\n")
                f.write("="*50 + "\n\n")
                for ch in generator.chapters:
                    f.write(f"# 第{ch.number}章：{ch.title}\n\n")
                    f.write(ch.content)
                    f.write("\n\n" + "="*50 + "\n\n")

            yield f"data: ✅ 第{chapter_num}章完成（{len(content)}字）\n\n"
            generated += 1
            if params.until_finale and is_finale(content, title):
                yield "data: 🎉 检测到大结局信号，续写结束。\n\n"
                break

        yield "data: [DONE]\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")


@app.get("/settings")
def get_settings():
    return settings.config


@app.post("/settings")
def update_settings(config: dict):
    settings.config.update(config)
    settings.save_config()
    return {"ok": True}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=False)


