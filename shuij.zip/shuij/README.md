手机端方案（直连AI，无需后端 + 可选本地后端）

本目录包含两部分：
- app/ Flutter 手机端（默认直连 AI，无需后端）
- backend/ 可选本地后端（FastAPI，若你想用局域网/云端也可用）

目录结构
- backend/
  - server.py 本地后端服务（SSE 流式输出）
  - requirements.txt 依赖

运行手机端（直连AI）
1. 安装 Flutter 环境（3.x），在 手机/app 下执行：
   flutter pub get
2. 连接真机或模拟器，运行：
   flutter run
3. 打包 APK：
   flutter build apk --release
 
 DeepSeek 使用提示
 - Provider 选 DeepSeek
 - API Base: https://api.deepseek.com/v1
 - Model: deepseek-chat
 - 在首页填入你的 DeepSeek API Key 即可使用

运行可选后端（本机）
1. 安装依赖（建议新建虚拟环境）：
   pip install -r 手机/backend/requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
2. 启动服务（默认 8000 端口）：
   python 手机/backend/server.py
3. 手机与电脑连同一 Wi‑Fi，在手机上访问：http://<电脑局域网IP>:8000

核心接口
- GET /projects  列出项目（保存目录下的小说文件夹）
- POST /projects/{id}/import (multipart)  上传单个 TXT 或 ZIP（文件夹打包）
- GET /projects/{id}/chapters  列出项目已有章节
- POST /projects/{id}/continue (JSON)  续写（支持直到大结局），SSE 流式输出
- POST /projects/{id}/clear (form)  清空，支持删除磁盘
- GET/POST /settings  获取/更新 AI 配置（与桌面共用）

与桌面版的互通
- 沿用桌面版配置与保存目录；相同项目可互相继续生成。
- 导入后自动识别起始章节（下一章）。

Flutter 前端对接建议
- 使用 SSE 订阅 /continue 的流式输出。
- 文件夹导入：将文件夹压缩为 zip 后上传 /import。
- 断点续写：GET /chapters 后默认起始=最后一章+1。

如需我提供 Flutter 最小可用工程与 APK 打包脚本，请告知。

